'use strict';
const {
  Model
} = require('sequelize');
const professor = require('./professor');
module.exports = (sequelize, DataTypes) => {
  class Adminstrador extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Adminstrador.hasMany(professor, {
        foreignKey: 'ProfessorId',
      });
      professor.belongsTo(Adminstrador);
    }
  }
  Adminstrador.init({
    data: DataTypes.DATE,
    AdminstradorId: DataTypes.INTEGER,
    email: DataTypes.STRING,
    senha: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Adminstrador',
  });
  return Adminstrador;
};