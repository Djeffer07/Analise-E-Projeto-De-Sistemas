'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Avalicoes extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Avalicoes.hasMany(Aluno, {
        foreignKey: 'AlunoId',
      });
      Aluno.belongsTo(Avalicoes);
    }
  }
  Avalicoes.init({
    data: DataTypes.DATE,
    AvalicacoesId: DataTypes.INTEGER,
    email: DataTypes.STRING,
    senha: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Avalicoes',
  });
  return Avalicoes;
};