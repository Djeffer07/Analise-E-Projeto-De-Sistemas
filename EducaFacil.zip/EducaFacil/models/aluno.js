'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Aluno extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Aluno.hasMany(avalicoes, {
        foreignKey: 'AvaliacoesId',
      });
      avalicoes.belongsTo(Aluno);
    }

  }
  Aluno.init({
    data: DataTypes.DATE,
    AlunoId: DataTypes.INTEGER,
    email: DataTypes.STRING,
    senha: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Aluno',
  });
  return Aluno;
};