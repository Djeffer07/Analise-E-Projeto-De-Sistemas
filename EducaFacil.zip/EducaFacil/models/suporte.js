'use strict';
const {
  Model
} = require('sequelize');
const professor = require('./professor');
const aluno = require('./aluno');
module.exports = (sequelize, DataTypes) => {
  class Suporte extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Suporte.hasMany(aluno, {
        foreignKey: 'AlunoId',
      });
      aluno.belongsTo(Suporte);

      Suporte.hasMany(professor, {
        foreignKey: 'ProfessorId',
      });
      professor.belongsTo(Suporte);
    }
  }
  Suporte.init({
    data: DataTypes.DATE,
    SuporterId: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Suporte',
  });
  return Suporte;
};