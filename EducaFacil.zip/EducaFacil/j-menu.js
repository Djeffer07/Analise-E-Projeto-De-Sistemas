const cursosElement = document.getElementById('cursos');
const dropdownMenu = document.getElementById('menu');
const sobreElement = document.getElementById('sobre');
const sobreMenu = document.getElementById('sobremenu');

cursosElement.addEventListener('mouseenter', () => {
    dropdownMenu.classList.add('show');
});

dropdownMenu.addEventListener('mouseenter', () => {
    dropdownMenu.classList.add('show');
});

cursosElement.addEventListener('mouseleave', () => {
    setTimeout(() => {
        if (!dropdownMenu.matches(':hover')) {
            dropdownMenu.classList.remove('show');
        }
    }, 200);
});

dropdownMenu.addEventListener('mouseleave', () => {
    setTimeout(() => {
        if (!cursosElement.matches(':hover')) {
            dropdownMenu.classList.remove('show');
        }
    }, 200);
});

sobreElement.addEventListener('mouseenter', () => {
    sobreMenu.classList.add('show');
});

sobreMenu.addEventListener('mouseenter', () => {
    sobreMenu.classList.add('show');
});

sobreElement.addEventListener('mouseleave', () => {
    setTimeout(() => {
        if (!sobreMenu.matches(':hover')) {
            sobreMenu.classList.remove('show');
        }
    }, 200);
});

sobreMenu.addEventListener('mouseleave', () => {
    setTimeout(() => {
        if (!sobreElement.matches(':hover')) {
            sobreMenu.classList.remove('show');
        }
    }, 200);
});
